import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataCombineComponent } from './data-combine.component';

describe('DataCombineComponent', () => {
  let component: DataCombineComponent;
  let fixture: ComponentFixture<DataCombineComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DataCombineComponent]
    });
    fixture = TestBed.createComponent(DataCombineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
