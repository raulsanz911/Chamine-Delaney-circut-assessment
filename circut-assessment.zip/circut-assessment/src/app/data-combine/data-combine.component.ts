import { Component, OnInit } from '@angular/core';
import { Observable, combineLatest, of } from 'rxjs';

@Component({
  selector: 'app-data-combine',
  templateUrl: './data-combine.component.html',
  styleUrls: ['./data-combine.component.css'],
})
export class DataCombineComponent implements OnInit {
  data1$: Observable<number[]> = of([]); // Initialize with an empty array
  data2$: Observable<string[]> = of([]); // Initialize with an empty array
  combinedData$: Observable<any> = of([]); // Initialize with an empty array

  constructor() {}

  ngOnInit(): void {
    this.data1$ = this.getData1();
    this.data2$ = this.getData2();

    // Combine both observables
    this.combinedData$ = combineLatest([this.data1$, this.data2$]);
  }

  private getData1(): Observable<number[]> {
    // Simulate data source 1
    return of([1, 2, 3]);
  }

  private getData2(): Observable<string[]> {
    // Simulate data source 2
    return of(['A', 'B', 'C']);
  }
}
